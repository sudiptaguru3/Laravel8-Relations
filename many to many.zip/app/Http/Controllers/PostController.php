<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Comment;
class PostController extends Controller
{
    //
    public function addPost()
    {
    	$post = new Post();
    	$post->title="Second Post Title";
    	$post->body="Second Post Description";
    	$post->save();
    	return "Post has been created";
    }
    public function addComment($id)
    {
    	$post = Post::find($id);
    	$comment = new comment();
    	$comment->comment="First Comment";
    	$post->comments()->save($comment);
    	return "Comment has been posted";
    }
    public function getCommentsByPost($id)
    {
    	$comments = Post::find($id)->Comments;
    	return $comments;
    }
}

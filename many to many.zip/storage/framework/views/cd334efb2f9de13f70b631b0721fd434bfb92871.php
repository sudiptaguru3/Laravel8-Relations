<!DOCTYPE html>
<html>
<head>
    <title>Laravel before_or_equal Date Validation Example</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css" integrity="sha512-oc9+XSs1H243/FRN9Rw62Fn8EtxjEYWHXRvjS43YtueEewbS6ObfXcJNyohjHqVKFPoXXUxwc+q1K7Dee6vv9g==" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js" integrity="sha512-8qmis31OQi6hIRgvkht0s6mCOittjMa9GMqtK9hes5iEQBQE/Ca6yGE5FsW36vyipGoWQswBj/QBm2JR086Rkw==" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" integrity="sha512-mSYUmp1HYZDFaVKK//63EcZq4iFWFjxSL+Z3T/aCt4IO9Cejm03q3NKKYN6pFQzY0SBOr8h+eCIAZHPXcpZaNw==" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ==" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8 offset-2 mt-5">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h3><strong>Laravel before_or_equal Date Validation Example</strong></h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('store-before-or-equal-date')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Start Date :</label>
                                <input class="datepicker form-control" name="start_date" value="<?php echo e(old('start_date')); ?>">
                                <?php if($errors->has('start_date')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('start_date')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>End Date :</label>
                                <input class="datepicker form-control" name="end_date" value="<?php echo e(old('end_date')); ?>">
                                <?php if($errors->has('end_date')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('end_date')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-success btn-sm">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $('.datepicker').datepicker({
            autoclose: true
        });
                $('.end-date').datepicker({
            autoclose: true
        });
    </script>
</body>
</html><?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\test\blog\resources\views/validation/beforeEqualDate.blade.php ENDPATH**/ ?>
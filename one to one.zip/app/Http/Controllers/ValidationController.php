<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ValidationController extends Controller
{
    public function beforeOrEqualDate()
    {
        return view('validation.beforeEqualDate');
    }

    public function beforeOrEqualDateStore(Request $request)
    {
        $request->validate([
            'start_date' => 'required',
            'end_date' => 'required|date|before:start_date'
        ]);
    }
}
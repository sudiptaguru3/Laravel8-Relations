<div>
    <!-- He who is contented is rich. - Laozi -->
    <h1>Hi</h1>
</div>
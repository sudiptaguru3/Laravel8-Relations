{{View::make('header')}}
<h3>hello world</h3>


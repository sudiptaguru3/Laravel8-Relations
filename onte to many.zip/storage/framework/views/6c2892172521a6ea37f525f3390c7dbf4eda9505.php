<?php echo e(View::make('header')); ?>

<h3>hello world</h3>

<?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\test\blog\resources\views/hello.blade.php ENDPATH**/ ?>